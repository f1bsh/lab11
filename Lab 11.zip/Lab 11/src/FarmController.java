import javafx.fxml.FXML;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.Pane;

public class FarmController {

    @FXML private Pane farmPane;
    @FXML private TreeView<FarmComponent> farmTree;

    private ItemContainer root;
    private Drone drone;

    @FXML
    public void initialize() {
        buildFarm();
        refreshTree();
        redrawFarm();
    }

    /** Build the farm hierarchy based on the test scenarios in the slides */
    private void buildFarm() {
        root = new ItemContainer("Root", 0, 0, 800, 600);

        // Barn with livestock area (containing a cow) and milk storage
        ItemContainer barn = new ItemContainer("Barn", 500, 300, 250, 200);
        ItemContainer livestock = new ItemContainer("Live-stock Area", 520, 320, 120, 100);
        FarmItem cow = new FarmItem("Cow", 540, 340, 40, 30);

        livestock.addChild(cow);
        barn.addChild(livestock);

        FarmItem milkStorage = new FarmItem("Milk Storage", 660, 400, 70, 50);
        barn.addChild(milkStorage);
        root.addChild(barn);

        // Storage building with tractor and tiller
        ItemContainer storage = new ItemContainer("Storage Building", 50, 400, 200, 150);
        FarmItem tractor = new FarmItem("Tractor", 70, 420, 50, 35);
        FarmItem tiller = new FarmItem("Tiller", 140, 420, 45, 30);
        storage.addChild(tractor);
        storage.addChild(tiller);
        root.addChild(storage);

        // Command center containing the drone
        ItemContainer commandCenter = new ItemContainer("Command Center", 350, 50, 100, 80);
        drone = Drone.getInstance(380, 75);
        commandCenter.addChild(drone);
        root.addChild(commandCenter);

        // Soy crop
        FarmItem soyCrop = new FarmItem("Soy Crop", 700, 100, 80, 120);
        root.addChild(soyCrop);
    }

    /** Sync the Composite tree into the TreeView */
    private void refreshTree() {
        TreeItem<FarmComponent> rootItem = buildTreeItem(root);
        farmTree.setRoot(rootItem);
        farmTree.setShowRoot(true);
    }

    private TreeItem<FarmComponent> buildTreeItem(FarmComponent component) {
        TreeItem<FarmComponent> item = new TreeItem<>(component);
        if (component instanceof ItemContainer container) {
            for (FarmComponent child : container.getChildren()) {
                item.getChildren().add(buildTreeItem(child));
            }
        }
        return item;
    }

    /** Clear and redraw all visualization nodes */
    private void redrawFarm() {
        farmPane.getChildren().clear();
        root.draw(farmPane);
    }

    @FXML
    private void onVisitItem() {
        TreeItem<FarmComponent> selected = farmTree.getSelectionModel().getSelectedItem();
        if (selected == null || selected.getValue() == null) return;
        FarmComponent target = selected.getValue();
        if (target instanceof Drone) return; // Don't fly to itself
        drone.visit(target);
    }

    @FXML
    private void onScanFarm() {
        drone.scanFarm();
    }
}