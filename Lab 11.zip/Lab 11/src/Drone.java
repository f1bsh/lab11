import javafx.animation.SequentialTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

/**
 * Singleton Drone responsible for "Visit Item / Container" and "Scan Farm" animations.
 */
public class Drone extends FarmComponent {

    private static Drone instance;
    private final Rectangle view;

    private Drone(double startX, double startY) {
        super("Drone", startX, startY, 30, 20);
        this.view = new Rectangle(startX, startY, 30, 20);
        this.view.setFill(Color.DARKRED);
        this.view.setStroke(Color.BLACK);
    }

    public static Drone getInstance(double startX, double startY) {
        if (instance == null) {
            instance = new Drone(startX, startY);
        }
        return instance;
    }

    @Override
    public Node getView() {
        return view;
    }

    @Override
    public void draw(Pane farmPane) {
        view.setX(getX());
        view.setY(getY());
        if (!farmPane.getChildren().contains(view)) {
            farmPane.getChildren().add(view);
        }
    }

    /** Fly to the center of the given FarmComponent */
    public void visit(FarmComponent target) {
        TranslateTransition tt = new TranslateTransition(Duration.seconds(2), view);
        double deltaX = target.getCenterX() - (getX() + getWidth() / 2.0);
        double deltaY = target.getCenterY() - (getY() + getHeight() / 2.0);
        tt.setByX(deltaX);
        tt.setByY(deltaY);
        tt.setOnFinished(e -> {
            // Sync logical coordinates after animation so subsequent visits work correctly
            setLocation(getX() + deltaX, getY() + deltaY);
            view.setTranslateX(0);
            view.setTranslateY(0);
        });
        tt.play();
    }

    /** Scan the entire farm: snake-like path covering (0,0) to (800,600) */
    public void scanFarm() {
        double stepY = 100; // Vertical step between scan rows
        double maxX = 800 - getWidth();
        double maxY = 600 - getHeight();

        SequentialTransition sequence = new SequentialTransition();
        boolean moveRight = true;
        double currentY = getY();

        while (currentY <= maxY) {
            // Horizontal sweep
            TranslateTransition horizontal = new TranslateTransition(Duration.seconds(1.5), view);
            horizontal.setToX(moveRight ? maxX : 0);
            sequence.getChildren().add(horizontal);
            moveRight = !moveRight;

            // Move down to the next row (unless we've reached the bottom)
            if (currentY + stepY <= maxY) {
                TranslateTransition down = new TranslateTransition(Duration.seconds(0.5), view);
                down.setByY(stepY);
                sequence.getChildren().add(down);
                currentY += stepY;
            } else {
                break;
            }
        }

        // Return to the starting position (optional)
        TranslateTransition reset = new TranslateTransition(Duration.seconds(1), view);
        reset.setToX(getX());
        reset.setToY(getY());
        sequence.getChildren().add(reset);

        sequence.play();
    }
}