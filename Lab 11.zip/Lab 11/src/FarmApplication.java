import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FarmApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader loader = new FXMLLoader(
                FarmApplication.class.getResource("/com/farm/FarmDashboard.fxml")
        );
        Scene scene = new Scene(loader.load(), 1100, 700);
        stage.setTitle("Farm Dashboard – Drone Simulation");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}