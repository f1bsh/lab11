import javafx.scene.Node;
import javafx.scene.layout.Pane;

/**
 * Component role in the Composite Pattern.
 * Both FarmItem (leaf) and ItemContainer (composite) extend this class.
 */
public abstract class FarmComponent {

    protected String name;
    protected double x, y;
    protected double width, height;

    public FarmComponent(String name, double x, double y, double width, double height) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getX() { return x; }
    public double getY() { return y; }
    public void setLocation(double x, double y) { this.x = x; this.y = y; }

    public double getWidth() { return width; }
    public double getHeight() { return height; }
    public void setDimensions(double width, double height) {
        this.width = width;
        this.height = height;
    }

    /** Center X coordinate — used by Drone.visit() */
    public double getCenterX() { return x + width / 2.0; }

    /** Center Y coordinate — used by Drone.visit() */
    public double getCenterY() { return y + height / 2.0; }

    /** Returns the JavaFX node for this component (implemented by subclasses) */
    public abstract Node getView();

    /** Draws/refreshes this component on the farmPane */
    public abstract void draw(Pane farmPane);

    @Override
    public String toString() { return name; }
}