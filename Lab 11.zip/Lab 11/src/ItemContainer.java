import java.util.ArrayList;
import java.util.List;

import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * Composite role in the Composite Pattern.
 * Can contain FarmItem and/or other ItemContainer instances.
 */
public class ItemContainer extends FarmComponent {

    private final List<FarmComponent> children = new ArrayList<>();
    private final Rectangle rectangle;

    public ItemContainer(String name, double x, double y, double width, double height) {
        super(name, x, y, width, height);
        this.rectangle = new Rectangle(x, y, width, height);
        this.rectangle.setFill(Color.SADDLEBROWN.deriveColor(0, 1, 1, 0.25));
        this.rectangle.setStroke(Color.SADDLEBROWN);
    }

    public void addChild(FarmComponent child) {
        children.add(child);
    }

    public void removeChild(FarmComponent child) {
        children.remove(child);
    }

    public List<FarmComponent> getChildren() {
        return children;
    }

    @Override
    public Node getView() {
        return rectangle;
    }

    @Override
    public void draw(Pane farmPane) {
        rectangle.setX(getX());
        rectangle.setY(getY());
        rectangle.setWidth(getWidth());
        rectangle.setHeight(getHeight());
        if (!farmPane.getChildren().contains(rectangle)) {
            farmPane.getChildren().add(rectangle);
        }
        // Recursively draw all children
        for (FarmComponent child : children) {
            child.draw(farmPane);
        }
    }
}