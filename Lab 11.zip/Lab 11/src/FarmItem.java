import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

/**
 * Leaf role in the Composite Pattern.
 * Represents a concrete item on the farm: Cow, Drone, Tractor, Soy Crop, etc.
 */
public class FarmItem extends FarmComponent {

    private final Rectangle rectangle;

    public FarmItem(String name, double x, double y, double width, double height) {
        super(name, x, y, width, height);
        this.rectangle = new Rectangle(x, y, width, height);
        this.rectangle.setFill(Color.DARKGREEN);
        this.rectangle.setStroke(Color.BLACK);
    }

    public void setColor(Color color) {
        rectangle.setFill(color);
    }

    @Override
    public Node getView() {
        return rectangle;
    }

    @Override
    public void draw(Pane farmPane) {
        rectangle.setX(getX());
        rectangle.setY(getY());
        rectangle.setWidth(getWidth());
        rectangle.setHeight(getHeight());
        if (!farmPane.getChildren().contains(rectangle)) {
            farmPane.getChildren().add(rectangle);
        }
    }
}